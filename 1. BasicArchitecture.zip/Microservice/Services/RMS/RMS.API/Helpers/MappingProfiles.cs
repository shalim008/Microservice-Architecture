using AutoMapper;
using Microsoft.AspNetCore.Identity;
using RMS.API.Dtos;
using RMS.Core.Entities;

namespace API.Helpers
{
    public class MappingProfiles : Profile
    {
        public MappingProfiles()
        {

            CreateMap<SysOwner, SysOwnerDto>().ReverseMap();
        }
    }
}