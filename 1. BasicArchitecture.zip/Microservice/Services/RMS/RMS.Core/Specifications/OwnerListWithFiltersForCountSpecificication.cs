﻿using RMS.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMS.Core.Specifications
{

    public class OwnerListWithFiltersForCountSpecificication : BaseSpecification<SysOwner>
    {
        public OwnerListWithFiltersForCountSpecificication(OwnerListSpecificationParams postParrams)
           : base(x =>
               (string.IsNullOrEmpty(postParrams.Search)) && (x.DataStatus == 1)
           )
        {
            //AddInclude(ob => ob.DcmCaseListCustomer);         
            AddOrderByDescending(x => x.Id);
        }

        public OwnerListWithFiltersForCountSpecificication(Int64 id)
          : base(x =>
              (x.Id == id) && (x.DataStatus == 1)
          )
        {
            AddOrderByDescending(x => x.Id);
        }
    }
}
