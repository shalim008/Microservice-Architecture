using System.ComponentModel.DataAnnotations.Schema;

namespace RMS.Core.Entities
{
    public class BaseEntity
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Int64 Id { get; set; }     
        public DateTimeOffset SetOn { get; set; } = DateTimeOffset.Now;
        public DateTimeOffset ModifiedOn { get; set; } = DateTimeOffset.Now;
        public int? SetBy { get; set; }
        public int? ModifiedBy { get; set; }
        public Int32 DataStatus { get; set; } = 1;
    }
}