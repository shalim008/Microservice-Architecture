﻿using System.Numerics;

namespace RMS.Core.Entities
{
    public class SysOwner : BaseEntity
    {
        public string OwnerName { get; set; }
        public string OwnerCode { get; set; }
        public string Description { get; set; }
        public Int64 ParentOwnerId { get; set; }
    }
}
