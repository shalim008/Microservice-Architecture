namespace RMS.Core.Interfaces
{
    public class IIdentityService
    {
        
    }
}